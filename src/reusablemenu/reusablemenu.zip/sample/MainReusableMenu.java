package reusablemenu.sample;

public class MainReusableMenu {

	public static void main(String[] args) {
		ApplicationMenu menu = new ApplicationMenu();
		menu.load();
		menu.execute();

	}

}
