package reusablemenu.sample;

import java.util.Scanner;

public class Student {

	private Scanner input = new Scanner(System.in);
	private int ID;
	private String nume;
	private String prenume;
	private String specializare;
	private int an_studii;
	Student()
	{
		nume = " ";
		prenume = " ";
		specializare = " ";
		an_studii = 0;
		ID = 0;
	}
	public void ReaderStudent(int id)
	{
		ID = id;
		System.out.println("Numele studentului este : ");
		nume = input.nextLine();
		System.out.println("Prenumele studentului este : ");
		prenume = input.nextLine();
		System.out.println("Specializarea studentului este : ");
		specializare = input.nextLine();
		System.out.println("Anul de studiu al studentului este : ");
		an_studii = input.nextInt();
	}
	@Override
	public boolean equals(Object o) {
	if (this == o) return true;
	if (o == null || getClass() != o.getClass()) return false;
	//the above line can be written as: if(!(o instaceof Student))
	Student student = (Student) o;
	return ID == student.ID;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getPrenume() {
		return prenume;
	}
	public void setPrenume(String prenume) {
		this.prenume = prenume;
	}
	public String getSpecializare() {
		return specializare;
	}
	public void setSpecialisare(String specializare) {
		this.specializare = specializare;
	}
	public int getAn_studii() {
		return an_studii;
	}
	public void setAn_studii(int an_studii) {
		this.an_studii = an_studii;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}

}
